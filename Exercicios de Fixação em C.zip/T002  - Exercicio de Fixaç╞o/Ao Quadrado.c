#include <stdio.h>
#include <conio.h>
#include <math.h>

main()

{	
	int num1;
	float a;
	
	puts("digite um valor");
	scanf("%i",&num1);
	
	a= pow (num1,2);
	printf("elevado ao quadrado eh: %f", a);
	
	
	
}
