#include <stdio.h>
#include <conio.h>
#include <math.h>

main() 
{
		float num1, num2, media;
		
		printf("digite um valor \n");
		scanf("%f",&num1);
		printf("digite um  outro valor \n");
		scanf("%f",&num2);
		media=(num1+num2)/2;
		printf("%.1f",media);
		
		
		
	
	
}
