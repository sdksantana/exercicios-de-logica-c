#include <conio.h>
#include <stdio.h>
#include <math.h>
 
main()

{
		int a, b;
		
		puts("digite sua idade");
		scanf("%i",&a);
		
		if (a >= 18) {
			
		printf("voce tem 18 anos ou mais %i",a);
		}
			else {
					printf("voce tem menos de 18 anos %i",a);
				
			}
			
		
	
	
	
	
	
}
