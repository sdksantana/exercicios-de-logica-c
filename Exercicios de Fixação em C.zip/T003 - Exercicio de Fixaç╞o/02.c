#include <conio.h>
#include <stdio.h>
#include <math.h>
 
main()

{
		int a;
		
		puts("digite sua idade");
		scanf("%i",&a);
		if 	(a >= 18) 
			puts("voce tem 18 anos ou mais");
		else 
			puts("voce tem menos de 18 anos");
			
		getch();
	
	
	
	
}
