#include <stdio.h>
#include <conio.h>
#include <math.h>

main()

{
	int a, b;
	
		printf("digite um valor ");
		scanf("%i",&a);
	
		printf("digite outro valor ");
		scanf("%i",&b);
	
	if (a == b)
		puts("numeros iguais ");
	
	else 
	
		if (a>b)
		printf("%i o maior numero eh ",a);
		
		else 
		printf("%i o maior numero eh", ); 
		
		getch();
	
	
	
}
